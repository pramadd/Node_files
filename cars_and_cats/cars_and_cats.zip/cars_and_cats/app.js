
var http = require('http');
var fs = require('fs');
var server = http.createServer(function (request, response){
console.log('client request URL: ', request.url);

//<<=================   Root route =============================>>>
    if(request.url === '/') {
        fs.readFile('index.html', 'utf8', function (errors, contents){
            response.writeHead(200, {'Content-Type': 'text/html'});  
            response.write(contents);  
            response.end(); 
        });
    }

//<<=================   Cars view =============================>>>
    else if(request.url === '/cars') {
        fs.readFile('views/cars.html', 'utf8', function (errors, contents){
            response.writeHead(200, {'Content-Type': 'text/html'});  
            response.write(contents);  
            response.end(); 
        });
    }

    else if(request.url === '/images/cars.jpeg'){
        fs.readFile('images/cars.jpeg', 'utf8', function (errors, contents){
            response.writeHead(200, {'Content-Type': 'images/jpeg'});  
            response.write(contents);  
            
            response.end(); 
        });
    }
//<<=================   Cats view =============================>>>
    else if(request.url === '/cats') {
            fs.readFile('views/cats.html', 'utf8', function (errors, contents){
                response.writeHead(200, {'Content-Type': 'text/html'});  
                response.write(contents);  
                
                response.end(); 
            });
        }
    
        else if(request.url === '/images/cats.jpeg'){
           fs.readFile('images/cats.jpeg', 'utf8', function (errors, contents){
               response.writeHead(200, {'Content-Type': 'images/jpeg'});  
               response.write(contents);  
               
               response.end(); 
           });
       
       }
//<<=================  New Car =============================>>>
       else  if(request.url === '/cars/new'){
           fs.readFile('views/new.html', 'utf8', function (errors, contents){
               response.writeHead(200, {'Content-Type': 'text/html'}); 
               response.write(contents);  
               response.end(); 
           });
       }
//<<=================   Error Display =============================>>>
       else {
           response.writeHead(404);
           response.end('File not found!!!');
       }

    });
    
    server.listen(6789);
    
    console.log("Running in localhost at port 6789");
   
   
        






